# Godot-MagicaVoxel-Importer
An Plugin for the GodotEngine to import MagicaVoxel's .vox format as meshes
For Godot verision 3.0

## How-To
Download the Plugin and put it into your projects folder

To Start importing select a .vox file and press '(Re)Import'

The .mesh file was now created.
If the mesh is plain white, the Color vertices are not enabled yet.
To enable them, add or edit the SpatialMaterial in 'Surface1' on the Mesh and enable 'Vertex Color/Use As Albedo' and 'Vertex Color/Is Srgb'. The colors should now show corretly.
Have fun!

